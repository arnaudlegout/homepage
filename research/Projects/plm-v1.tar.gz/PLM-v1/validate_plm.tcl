set packetSize 500
set runtime 80
set scenario 2
set plm_debug_flag 3; #from 0 to 3: 0 no output, 3 full output
set rates "20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3 20e3"
set level [llength $rates]
set rates_cum [calc_cum $rates]
puts stderr $rates_cum
set run_nam 0

set check_estimate 1
set Queue_sched_ FQ
set PP_burst_length 2
set PP_estimation_length 3


Class Scenario2 -superclass PLMTopology

#This scenario is for validation purpose. It aims to trigger most of
#the PLM functionalities.
Scenario2 instproc init args {
	
    eval $self next $args
    $self instvar ns node
    global f check_estimate nb_plm
    
    set nb_src 20
    Queue/DropTail set limit_ 5
 
    $self build_link 0 1 200ms 200e3
    $ns duplex-link-op $node(0) $node(1) queuePos 0.5
  
    #create sources links
    for {set i 2} {$i<=[expr $nb_src + 1]} {incr i} {
	set delay [expr 5 * $i]ms
	set bp ${i}e5
	puts stderr "$delay $bp"
	$self build_link $i 0 $delay  $bp
    }

    #create receivers links
    for {set i [expr $nb_src + 2]} {$i<=[expr 2 * $nb_src + 1]} {incr i} {
	set delay [expr 4 * ($i -20)]ms
	set bp [expr $i - 20]e5
	puts stderr "$delay $bp"
	$self build_link 1 $i $delay  $bp
    }

    #place three PLM sources
    for {set i 2} {$i <= 4} {incr i} {
	set addr($i) [$self place_source $i 3]
    }
    puts stderr "sender placed"

    #place six PLM receiver: 2 receivers per source
    set j 2
    for {set i 2} {$i <=  7} {incr i 2} {
	set time [expr $i/2. + 3]
	$self place_receiver [expr $i + $nb_src] $addr($j) $time $check_estimate $i
	$self place_receiver [expr $i + $nb_src +1] $addr($j) $time $check_estimate [expr $i + 1]
	incr j
    }
    

    for {set i 1} {$i<=10} {incr i} {
	set null($i) [new Agent/Null]
	set udp($i) [new Agent/UDP]
	$udp($i) set fid_ [expr $i + 3]
	$ns attach-agent $node([expr $i + 4]) $udp($i)
	$ns attach-agent $node([expr $i + 27]) $null($i)
	$ns connect $udp($i) $null($i)
	set cbr($i) [new Application/Traffic/CBR]
	$cbr($i) attach-agent $udp($i)
	$cbr($i) set random_ 0
	$cbr($i) set rate_ 1Mb
	$cbr($i) set packet_size_ 1000
    }
    puts stderr "receivers placed"  
    
    for {set i 1} {$i<=3} {incr i} {
	$ns at 10 "$cbr($i) start"
	$ns at 15 "$cbr($i) stop"
    }
    
    for {set i 1} {$i<=10} {incr i} {
	$ns at 20 "$cbr($i) start"
	$ns at 25 "$cbr($i) stop"
    }
    #mcast set up
    DM set PruneTimeout 1000
    set mproto DM
    set mrthandle [$ns mrtproto $mproto {} ]
}


Simulator instproc finish {} {
    global run_nam PLMrcvr

    puts finish
    if {$run_nam} {
	puts "running nam..."
	exec nam -g 600x700 -f dynamic-nam.conf out.nam &
    }
    for {set i 2} {$i <=  7} {incr i} {
	puts "$PLMrcvr($i)"
	puts stderr [$PLMrcvr($i) plm_pkts]
	puts stderr [$PLMrcvr($i) plm_loss]
    }
    
    exit 0
}

Simulator instproc tick {} {
	puts stderr [$self now]
	$self at [expr [$self now] + 10.] "$self tick"
}

set ns [new Simulator -multicast on]
$ns multicast

$ns color 1 blue
$ns color 2 green
$ns color 3 red
$ns color 4 white
# prunes, grafts
$ns color 30 orange
$ns color 31 yellow

set f [open validate_plm.tr w]
$ns trace-all $f
#$ns namtrace-all [open out.nam w]

$ns tick
set scn [new Scenario$scenario $ns]
$ns at [expr $runtime +1] "$ns finish"
$ns run

