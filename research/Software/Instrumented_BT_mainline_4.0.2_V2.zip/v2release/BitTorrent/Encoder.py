# The contents of this file are subject to the BitTorrent Open Source License
# Version 1.0 (the License).  You may not copy or use this file, in either
# source code or executable form, except in compliance with the License.  You
# may obtain a copy of the License at http://www.bittorrent.com/license/.
#
# Software distributed under the License is distributed on an AS IS basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
# for the specific language governing rights and limitations under the
# License.

# Written by Bram Cohen

from socket import error as socketerror
from socket import gethostbyname
from socket import gethostname
#from binascii import b2a_qp

from BitTorrent.Connecter import Connection
from BitTorrent import BTFailure, is_frozen_exe

# PREEMPTION: for choosing a random connection
import random

# header, reserved, download id, my id, [length, message]


class Encoder(object):

    # PEX: Encoder accepts 'private' and 'reported_port' properties as well
    def __init__(self, make_upload, downloader, choker, numpieces, ratelimiter,
               raw_server, config, private, reported_port, my_id, schedulefunc, download_id,
               context, logcollector):
        self.make_upload = make_upload
        self.downloader = downloader
        self.choker = choker
        self.numpieces = numpieces
        self.ratelimiter = ratelimiter
        self.raw_server = raw_server
        self.my_id = my_id
        self.config = config
        self.schedulefunc = schedulefunc
        self.download_id = download_id
        self.context = context
        self.everinc = False
        self.connections = {}
        self.complete_connections = {}
        # contains the (IP, port) pairs of peers we know of, but haven't initiated connections
        # to due to max_initiate limit
        self.spares = []  
        self.banned = {}
        self.logcollector=logcollector
        schedulefunc(self.send_keepalives, config['keepalive_interval'])
        # PEX: record port and schedule the first peer exchange message
        self.reported_port = reported_port
        if not private and self.config['utorrent_extension']:
            schedulefunc(self.send_pex, config['pex_interval'])

    def send_keepalives(self):
        self.schedulefunc(self.send_keepalives,
                          self.config['keepalive_interval'])
        for c in self.complete_connections:
            c.send_keepalive()

    # PEX: sends a peer exchange message to all peers in the peer set,
    # and re-schedules the task to run again later
    def send_pex(self):
        self.schedulefunc(self.send_pex, self.config['pex_interval'])
        pex_set = set()
        for c in self.complete_connections:
            if c.listening_port:
                pex_set.add((c.ip, c.listening_port))
        for c in self.complete_connections:
            c.send_pex(pex_set)

    # PREEMPTION: added an argument denoting whether this connection attempt is to
    # a peer we discovered via the tracker
    def start_connection(self, dns, id, from_tracker):
        # HACK to get things working when tracker and seed are on the same machine;
        # tracker then returns "127.0.0.1" as the seed IP address
        #if dns[0] == "127.0.0.1":
        #    dns = ("131.179.80.22", dns[1])
        
        if dns[0] in self.banned:
            return
        if id == self.my_id:
            return
        for v in self.connections.values():
            if id and v.id == id:
                return
            if self.config['one_connection_per_ip'] and v.ip == dns[0]:
                return
        self.logcollector.log(None,'3.9','CONS INI ' + str(self.config['max_initiate']) + ' ' + str(len(self.connections))) 
        if len(self.connections) >= self.config['max_initiate']:
            # PREEMPTION: only add tracker-discovered peers to self.spares
            if len(self.spares) < self.config['max_initiate'] and \
                   dns not in self.spares and from_tracker:
                self.spares.append(dns)
            return

        for v in self.connections.values():
            #self.logcollector.log(None,'3.6','DEBUG ' + str(v.ip) + ' ' + str(dns[0]) + ' ' + str(v.listening_port) + ' '+ str(dns[1]))
            if v.ip == dns[0] and v.listening_port == dns[1]:
                self.logcollector.log(None,'3.6','PEX AC ' + str(dns[0]) + ' ' + str(dns[1]))
                return 
            if gethostbyname(gethostname()) == dns[0] and self.reported_port == dns[1]:
                self.logcollector.log(None,'3.6','PEX AC ' + str(dns[0]) + ' ' + str(dns[1]))
                return 


        #AL: I have not modified the log entry dns[0] that only returns the IP address
        #but not the port number even if the logcollector can now return as a peerID
        #its IP address + port number. The reason is that the CON ST/SE/SS entries
        #are only used in an old code that needs to be backward compatible.
        #However, it case it is needed for debugging reasons, the dns[0] can be replaced
        #with a dns entry, which logs the IP address and the port number. 
        self.logcollector.log(None,'3.3','CON ST ' + str(dns[0]))
        try:
            c = self.raw_server.start_connection(dns, None, self.context)
        except socketerror:
            self.logcollector.log(None,'3.4','CON SE ' + str(dns[0]))
            pass
        else:
            self.logcollector.log(None,'3.5','CON SS ' + str(dns[0]))
            # PREEMPTION: also pass from_tracker
            con = Connection(self, c, id, True, from_tracker, self.logcollector, dns)
            self.connections[c] = con
            c.handler = con

    #called when the connection handshake is done
    def connection_completed(self, c):
        if c.locally_initiated:
            self.logcollector.log(None,'3.1','CONH L ' + self.logcollector.peerID(c) + ' ID ' + str(c.id) + ' U ' + str(c.uses_utorrent_extension) + ' T ' + str(c.from_tracker) )
        else:
            self.logcollector.log(None,'3.2','CONH R ' + self.logcollector.peerID(c) + ' ID ' + str(c.id) + ' U ' + str(c.uses_utorrent_extension) + ' T ' + str(c.from_tracker) )
        self.complete_connections[c] = 1
        c.upload = self.make_upload(c)
        c.download = self.downloader.make_download(c)
        self.choker.connection_made(c)
        # PEX: send the first PEX message to this peer right away?
        if self.config['pex_send_immediately']:
            pex_set = set()
            for con in self.complete_connections:
                if con.listening_port:
                    pex_set.add((con.ip, con.listening_port))
            c.send_pex(pex_set)

    def ever_got_incoming(self):
        return self.everinc

    def how_many_connections(self):
        return len(self.complete_connections)

    def replace_connection(self):
        while len(self.connections) < self.config['max_initiate'] and \
                  self.spares:
            # PREEMPTION: only tracker-discovered peers are added in self.spares
            self.start_connection(self.spares.pop(), None, True) 

    def close_connections(self):
        for c in self.connections.itervalues():
            if not c.closed:
                c.connection.close()
                c.closed = True

    # called from the handshake handler to decide whether to accept a new incoming connection
    def singleport_connection(self, listener, con):
        if con.ip in self.banned:
            self.logcollector.log(None,'3.7', 'CONS B '+ str(con.ip)) 
            return
        m = self.config['max_allow_in']
        if is_frozen_exe:
            # chop max_allow_in to 55 to maybe prevent TCP stack flaking
            m = min(m, 55)
            if self.config['chop_max_allow_in']:
                # chop max_allow_in to 30 to more aggressively prevent TCP stack flaking
                m = min(m, 30)
        # PREEMPTION: instead of returning, check if the remote peer discovered us via the tracker,
        # and, if so, close a random connection and accept the new connection from that peer
        self.logcollector.log(None,'3.8', 'CONS IN ' + str(m) + ' ' + str(len(self.connections))) 
        if m and len(self.connections) >= m: 
            if (not self.config['preemption']) or (not con.from_tracker) or \
                   (not self.complete_connections):
                return
            else:
                # try to find an appropriate connection max_allow_in times, else choose at random
                con.preempted_another = True
                while (True):
                    random.seed()
                    c = random.choice(self.complete_connections.keys())
                    m -= 1
                    if ((not c.locally_initiated) and c.upload.choked and (not c.download.active_requests)) or \
                           (m == 0):
                        break
                c.got_preempted = True
                c.close() 

        self.logcollector.log(None,'4.2', 'CON R ' + self.logcollector.peerID(con)
                              + ' PREEMPTED_ANOTHER ' + str(con.preempted_another))            
        self.connections[con.connection] = con
        del listener.connections[con.connection]
        con.encoder = self
        con.connection.context = self.context

    def ban(self, ip):
        self.banned[ip] = None


class SingleportListener(object):

    def __init__(self, rawserver, logcollector):
        self.rawserver = rawserver
        self.port = 0
        self.ports = {}
        self.torrents = {}
        self.connections = {}
        self.download_id = None
        self.logcollector=logcollector

    def _check_close(self, port):
        if not port or self.port == port or self.ports[port][1] > 0:
            return
        serversocket = self.ports[port][0]
        self.rawserver.stop_listening(serversocket)
        serversocket.close()
        del self.ports[port]

    def open_port(self, port, config):
        if port in self.ports:
            self.port = port
            return
        serversocket = self.rawserver.create_serversocket(
            port, config['bind'], reuse=True, tos=config['peer_socket_tos'])
        self.rawserver.start_listening(serversocket, self)
        oldport = self.port
        self.port = port
        self.ports[port] = [serversocket, 0]
        self._check_close(oldport)

    def get_port(self):
        if self.port:
            self.ports[self.port][1] += 1
        return self.port

    def release_port(self, port):
        self.ports[port][1] -= 1
        self._check_close(port)

    def close_sockets(self):
        for serversocket, _ in self.ports.itervalues():
            self.rawserver.stop_listening(serversocket)
            serversocket.close()

    def add_torrent(self, infohash, encoder):
        if infohash in self.torrents:
            raise BTFailure("Can't start two separate instances of the same "
                            "torrent")
        self.torrents[infohash] = encoder

    def remove_torrent(self, infohash):
        del self.torrents[infohash]

    def select_torrent(self, conn, infohash):
        if infohash not in self.torrents:
            return
        self.torrents[infohash].singleport_connection(self, conn)

    # called from the listening socket to initialize a new Connection object
    # for an incoming connection
    def external_connection_made(self, connection):
        # PREEMPTION: pass False (the default) for from_tracker; maybe be turned to
        # True later in the handshake handler
        con = Connection(self, connection, None, False, False, self.logcollector)
        self.connections[connection] = con
        connection.handler = con

    def replace_connection(self):
        pass
