#!/usr/bin/env python

from datetime import datetime
from time import time
from BitTorrent.Connecter import Connection

#debug=0 means no verbose mode, debug!=0 means verbose mode
#setting debug to 0 significantly reduces the size of the log
#file as all the spew logs are no more dumped into the log file.
debug=0

#connectionID=0 when a peer is identified by its IP address, 
#and connectionID=1 when a peer is identified by its peer ID.
#and connectionID=2 when a peer is identified by its IP.port
#This connectionID is only taken into account in the log files.
connectionID=1

#Here we define the messages to be logged
#(btdownloadheadless.py)
#1.1 Legend  
#1.2 GS  
#1.3 FN  
#1.4 CF  
#1.5 EC  

#(Choker.py)
#2.1 PRU 
#2.2 SRU 
#2.3 SKU 
#2.4 POU I 
#2.5 POU NI 
#2.6 PPOU 
#2.7 SB 
#2.8 INT LP 
#2.9 GSP 
#2.10 INT 
#2.11 INT NFU 

#(Encoder.py)
#3.1 CONH L 
#3.2 CONH R 
#3.3 CON ST 
#3.4 CON SE 
#3.5 CON SS 
#3.6 PEX AC
#3.7 CONS B
#3.8 CONS IN
#3.9 CONS INI

#(Connecter.py)
#4.1 CON L 
#4.2 CON R 
#4.3 S I 
#4.4 S NI 
#4.5 S C 
#4.6 S UC  
#4.7 S R 
#4.8 S P 
#4.9 S CA 
#4.10 S H 
#4.11 S KA 
#4.12 R KA 
#4.13 R CA 
#4.14 CON C 
#4.15 CONH C 
#4.16 S BF
#4.17 S PEX
#4.18 R PEX
#4.19 R PI

#(Uploader.py)
#5.1 R I
#5.2 R NI
#5.3 R R
#5.4 CON C <IP> E

#(Downloader.py)
#6.1 R C 
#6.2 R UC
#6.3 R H
#6.4 R BF
#6.5 P <IP> S
#6.6 CON C <IP> S
#6.7 R P

#(Rerequester.py)
#7.1 RT NL
#7.2 RT ID
#7.3 RT NP 
#7.4 RT P

#(download.py)
#8.1 P ID
#8.2 P SM

#(StorageWrapper.py)
#9.1 P EG


#messagesToLog['x']=1 means that the message will be logged.
#All messages
messagesToLog={'1.1':1, '1.2':1, '1.3':1, '1.4':1, '1.5':1, '2.1':1 , '2.2':1 , '2.3':1, '2.4':1 , '2.5':1, '2.6':1, '2.7':1, '2.8':1, '2.9':1, '2.10':1, '2.11':1, '3.1':1, '3.2':1, '3.3':1, '3.4':1, '3.5':1, '3.6':1, '3.7':1, '3.8':1, '3.9':1, '4.1':1, '4.2':1, '4.3':1, '4.4':1, '4.5':1, '4.6':1, '4.7':1, '4.8':1, '4.9':1, '4.10':1, '4.11':1, '4.12':1, '4.13':1, '4.14':1, '4.15':1, '4.16':1, '4.17':1,  '4.18':1, '4.19':1, '5.1':1, '5.2':1, '5.3':1, '5.4':1, '6.1':1, '6.2':1, '6.3':1, '6.4':1, '6.5':1, '6.6':1, '6.7':1, '7.1':1, '7.2':1, '7.3':1, '7.4':1, '8.1':1, '8.2':1,'9.1':1}

#No messages
#messagesToLog={'1.1':0, '1.2':0, '1.3':0, '1.4':0, '1.5':0, '2.1':0 , '2.2':0 , '2.3':0, '2.4':0 , '2.5':0, '2.6':0, '2.7':0, '2.8':0, '2.9':0, '2.10':0, '2.11':0, '3.1':0, '3.2':0, '3.3':0, '3.4':0, '3.5':0, '3.6':0, '3.7':0, '3.8':0, '3.9':0,'4.1':0, '4.2':0, '4.3':0, '4.4':0, '4.5':0, '4.6':0, '4.7':0, '4.8':0, '4.9':0, '4.10':0, '4.11':0, '4.12':0, '4.13':0, '4.14':0, '4.15':0, '4.16':0,  '4.17':0,  '4.18':0, '4.19':0, '5.1':0, '5.2':0, '5.3':0, '5.4':0, '6.1':0, '6.2':0, '6.3':0, '6.4':0, '6.5':0, '6.6':0, '6.7':0, '7.1':0, '7.2':0, '7.3':0, '7.4':0, '8.1':0, '8.2':0,'9.1':0}

#for experiments with minimal logs
#messagesToLog={'1.1':0, '1.2':0, '1.3':1, '1.4':1, '1.5':1, '2.1':0 , '2.2':0 , '2.3':0, '2.4':0 , '2.5':0, '2.6':0, '2.7':0, '2.8':0, '2.9':0, '2.10':0, '2.11':0, '3.1':1, '3.2':1, '3.3':0, '3.4':0, '3.5':0, '3.6':0, '3.7':0, '3.8':0, '3.9':0,'4.1':0, '4.2':0, '4.3':0, '4.4':0, '4.5':0, '4.6':0, '4.7':0, '4.8':0, '4.9':0, '4.10':0, '4.11':0, '4.12':0, '4.13':0, '4.14':0, '4.15':1, '4.16':0,  '4.17':0,  '4.18':0, '4.19':1, '5.1':0, '5.2':0, '5.3':0, '5.4':0, '6.1':0, '6.2':0, '6.3':0, '6.4':0, '6.5':0, '6.6':0, '6.7':0, '7.1':1, '7.2':0, '7.3':1, '7.4':0, '8.1':1, '8.2':1,'9.1':0}

#debugs
#messagesToLog={'1.1':1, '1.2':0, '1.3':1, '1.4':1, '1.5':1, '2.1':0 , '2.2':0 , '2.3':0, '2.4':0 , '2.5':0, '2.6':0, '2.7':0, '2.8':0, '2.9':0, '2.10':0, '2.11':0, '3.1':1, '3.2':1, '3.3':1, '3.4':1, '3.5':1, '3.6':1, '3.7':1, '3.8':1, '3.9':1, '4.1':1, '4.2':1, '4.3':0, '4.4':0, '4.5':0, '4.6':0, '4.7':0, '4.8':0, '4.9':0, '4.10':0, '4.11':0, '4.12':0, '4.13':0, '4.14':1, '4.15':1, '4.16':0,  '4.17':1,  '4.18':1, '4.19':1, '5.1':0, '5.2':0, '5.3':0, '5.4':1, '6.1':0, '6.2':0, '6.3':0, '6.4':0, '6.5':1, '6.6':1, '6.7':0, '7.1':1, '7.2':1, '7.3':1, '7.4':1, '8.1':1, '8.2':1,'9.1':1}


class LogCollector(object):
    def __init__(self, logfile):
        """
        write logs in the file passed to the constructor of the class.
        """
        self.logfile = logfile
        
    def closelog(self):
        #do not close anymore the file, but flush it. When the option next_torrent_time 
        #is used to stop the client after a given period of time, the logfile is closed, 
        #but data may try to be writen into the file after this event, which results
        #in a crash of the client before it has time to notify the tracker that it leaves
        #the torrent. 
        #self.logfile.close()
        self.logfile.flush()

    def now(self, sep=None):
        return datetime.now().isoformat(sep)

    def log(self,verbose=0, messageType=0, compact=0):
        if verbose and debug:
            self.logfile.write(self.now(' ') + ' ' + str(time()) + ' DEBUG ' + verbose + '\n')
            self.logfile.flush()
        if compact:
            #self.logfile.write(self.now(' ') + ' ' + compact + '\n')
            if messagesToLog[messageType]:
                self.logfile.write(str(time()) + ' ' + compact + '\n')        
                self.logfile.flush()

    def peerID(self,connection, portNumber=-1):
       if connectionID==0:
           return str(connection.ip)
       elif connectionID==1:
           return str(connection.id)
       elif connectionID==2:
           #in case the port number is not be defined. 
           try:
               return connection.connection.socket.getpeername()[0] + '.'+ str(connection.connection.socket.getpeername()[1])
           except:
               if portNumber>0:
                   return connection.ip + '.' + str(portNumber)
               else:
                   return 'ERROR in LogCollector.py'
    

if __name__ == '__main__':
    """
    Test of the class LogCollector.
    """
    import sys
    collector=LogCollector(sys.argv[1])
    print collector.now(' ')
    for i in sys.argv[2:]:
        collector.log(i)
    collector.closelog()
